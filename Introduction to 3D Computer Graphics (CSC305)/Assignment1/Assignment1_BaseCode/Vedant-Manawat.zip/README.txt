Name: Vedant Manawat   
VNumber: V00904582

Feb 16, 2021

CSC 305 Assignment 1

This is the README file for the corresponding assignment submissions. This file containts a list of objectives accomplished/not accomplished by me in order to complete the assignment.

List of tasks accomplished:

    1. Use of real-time to synchronize animations
    2. Ground box present 
    3. Two rocks in the shape of spheres
    4. Seaweeds modeled with each strand having 10 ellipses
    5. Seaweed animation is present
    6. Fish modeled with 2 eyes with pupils, 1 head, 1 body and 2 tail fins
    7. Fish animation is presnet, moves up and down in a waveform manner and revolves around the seasweeds
    8. Modeled human character with no arms 
    9. The human character moves up and down in the x and y direction 
    10. The legs of the character kick back and forth as they move up and down 
    11. The scene is 512x512
    12. Included the README.txt file

List of tasks not accomplished:

    1. Making bubbles emerging from the human character