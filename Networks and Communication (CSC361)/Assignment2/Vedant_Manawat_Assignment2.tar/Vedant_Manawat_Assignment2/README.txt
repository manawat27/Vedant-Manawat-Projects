Vedant Manawat 
V00904582
CSC 361 Assignment2 
March 5 Spring 2021

### How to run the code 
Run the code with: 
1) python3 Assignment2.py file-name.cap

When running replace 'file-name.cap' with an actual cap file, for example, sample-capture-file.cap

